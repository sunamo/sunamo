﻿// Toto nikdy ned�lej, je zde cycling collection, kde m��e� nastavit Cycling
public class CollectionToEnd<T> : CyclingCollection<T>
{
    public CollectionToEnd() : base(false)
    {

    }
}

﻿public class Distance2
{
    public double km = 0;
    public double m = 0;
}

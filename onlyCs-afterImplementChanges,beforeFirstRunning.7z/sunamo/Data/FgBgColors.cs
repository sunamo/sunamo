﻿/// <summary>
/// Lze použít na hex vyjádření nebo třeba na barvy bg- a fg- v Metro UI CSS FW
/// </summary>
public class FgBgColors
{
    public string fg = "";
    public string bg = "";
}

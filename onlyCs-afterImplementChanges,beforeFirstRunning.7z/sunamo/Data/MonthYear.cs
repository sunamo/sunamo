﻿public class MonthYear
{
    public int month = 0;
    public int year = 0;


}



﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sunamo.Data
{
    public class ItemWithCount<T>
    {
        public T t = default(T);
        public int count = 0;
    }
}

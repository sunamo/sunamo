﻿public class ABT<Key, Value>
{
    public Key A;
    public Value B;

    public ABT(Key a, Value b)
    {
        this.A = a;
        this.B = b;
    }

    public ABT()
    {

    }
}

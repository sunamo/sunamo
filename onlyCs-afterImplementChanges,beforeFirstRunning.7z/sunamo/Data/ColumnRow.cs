﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sunamo
{
    public class ColumnRow
    {
        public int Column = 0;
        public int Row = 0;
    }
}

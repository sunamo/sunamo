﻿using System;
using System.Collections.Generic;
using System.Text;

namespace sunamo.Data
{
    public class LoginData
    {
        public string Login;
        public string Pw;
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;


    /// <summary>
    /// Is using when the code can't be implemented because it's non logic and avoid showing in search result
    /// 
    /// </summary>
    public class NoImplementedException : Exception
    {
    }


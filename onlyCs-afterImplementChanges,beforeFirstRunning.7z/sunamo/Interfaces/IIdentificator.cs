﻿public interface IIdentificator
{
    object Id { get; set; }
}

﻿public enum ResultLogin
{

}

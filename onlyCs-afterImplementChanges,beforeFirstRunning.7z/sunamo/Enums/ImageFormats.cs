﻿using System;
using System.Collections.Generic;
using System.Text;

    public enum ImageFormats
    {
        Jpg,
        Png,
        Gif,
    None
}


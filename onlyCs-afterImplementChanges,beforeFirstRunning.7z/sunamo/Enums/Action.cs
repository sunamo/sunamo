﻿namespace sunamo
{
    public enum Action
    {
        Nope,
        Remove,
        SaveToClipboard,
        Run
    }
}

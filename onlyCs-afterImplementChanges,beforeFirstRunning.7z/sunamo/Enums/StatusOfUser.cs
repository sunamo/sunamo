﻿public enum StatusOfUser : byte
{
    Banned = 0,
    Allowed = 1,
    Admin = 2

}

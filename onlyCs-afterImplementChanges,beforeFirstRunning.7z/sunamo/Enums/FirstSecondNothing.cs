﻿public enum FirstSecondNothing
{
    First,
    Second,
    Nothing
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace sunamo.Enums
{
    public enum DirectoryCreateCollisionOption
    {
        Delete,
        Overwrite,
        AddSerie
    }
}

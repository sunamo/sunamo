﻿/// <summary>
/// 
/// </summary>
public enum DebugOutput
{
    MessageBox,
    Debug,
    CustomForm
}

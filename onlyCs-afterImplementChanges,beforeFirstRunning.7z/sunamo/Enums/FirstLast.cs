﻿public enum FirstLast
{
    First,
    Last
}

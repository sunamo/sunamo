﻿using System;
using System.Collections.Generic;
using System.Text;


    public enum DumpProvider
    {
    Microsoft,
    Newtonsoft,
    Reflection,
    Yaml,
    ObjectDumper
}


﻿/// <summary>
/// Zkratka pro SignedUnsigned
/// </summary>
public enum Signed
{
    Signed,
    Unsigned,
    Other
}

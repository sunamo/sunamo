﻿namespace sunamo
{
    public enum WizardResult
    {
        Finished,
        Canceled
    }
}

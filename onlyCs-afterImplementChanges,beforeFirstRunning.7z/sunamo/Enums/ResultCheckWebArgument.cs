﻿public enum ResultCheckWebArgument
{
    WrongRange,
    Empty,
    NotFound,
    AllOk
}

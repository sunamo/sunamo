﻿/// <summary>
/// Operace, ktere muze provest dat. adapter na DB
/// </summary>
public enum SqlMethods
{
    Insert,
    Delete,
    Update,
    Select
}

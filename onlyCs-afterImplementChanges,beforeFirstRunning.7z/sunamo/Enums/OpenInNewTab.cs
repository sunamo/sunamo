﻿public enum OpenInNewTab
{
    Never,
    Always,
    Prompt,
    Allow
}

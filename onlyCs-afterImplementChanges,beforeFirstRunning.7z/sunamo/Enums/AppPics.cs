﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sunamo
{
    public enum AppPics
    {
        Home,
        Next,
        Previous,
        Reload,
        BoardPin,
        Logout,
        CurrentFolder,
        ArrowHeadUp,
        Import
    }
}

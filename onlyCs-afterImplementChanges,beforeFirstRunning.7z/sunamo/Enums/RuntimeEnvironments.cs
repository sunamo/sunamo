﻿using System;
using System.Collections.Generic;
using System.Text;

namespace sunamo.Enums
{
    public enum RuntimeEnvironments
    {
        Android,
        Windows,
        Chrome,
        Web,
        Wordpress,
        Developer
    }
}

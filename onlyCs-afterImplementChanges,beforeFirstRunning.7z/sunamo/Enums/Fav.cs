﻿public enum Fav
{
    Faved,
    NonFaved,
    All
}

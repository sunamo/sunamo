﻿public enum VariableModifiers
{
    // TODO: Make all None values in enums as first, because will have zero value 
    Mapped,
    None,
    ReadOnly
}

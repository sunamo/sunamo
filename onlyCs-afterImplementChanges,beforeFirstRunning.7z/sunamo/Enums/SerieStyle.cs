﻿using System;
using System.Collections.Generic;
using System.Text;

namespace sunamo.Enums
{
    public enum SerieStyle
    {
        Dash,
        Brackets,
        Underscore,
        All
    }
}

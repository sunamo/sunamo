﻿public enum CssFramework
{
    Materialize,
    Metro
}

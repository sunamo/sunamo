﻿public enum FileExceptions
{
    None,
    FileNotFound,
    UnauthorizedAccess,
    General
}

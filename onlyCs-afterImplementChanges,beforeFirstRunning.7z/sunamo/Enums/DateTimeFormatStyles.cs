﻿using System;
using System.Collections.Generic;
using System.Text;

namespace sunamo.Enums
{
    public enum DateTimeFormatStyles
    {
        /// <summary>
        /// 2011-10-18 10:30
        /// </summary>
        FullCalendar
    }
}

﻿public enum WordsIn
{
    Contents,
    Titles,
    Both

}

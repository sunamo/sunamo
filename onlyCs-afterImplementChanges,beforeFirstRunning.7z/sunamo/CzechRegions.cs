﻿public enum CzechRegions
{
    /*
     * 

     */
}

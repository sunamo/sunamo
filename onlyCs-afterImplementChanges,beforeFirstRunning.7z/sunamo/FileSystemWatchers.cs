﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace sunamo
{
    public class FileSystemWatchers
    {
        Dictionary<string, FileSystemWatcher> watchers = new Dictionary<string, FileSystemWatcher>();
        VoidStringT<bool> onStart;
        VoidStringT<bool> onStop;

        public FileSystemWatchers(VoidStringT<bool> onStart, VoidStringT<bool> onStop)
        {
            this.onStart = onStart;
            this.onStop = onStop;
        }

        public void Start(string path)
        {
            if (!watchers.ContainsKey(path))
            {
                onStart.Invoke(path, true);
                FileSystemWatcher fileSystemWatcher = new FileSystemWatcher(path);
                fileSystemWatcher.Deleted += FileSystemWatcher_Deleted;
                fileSystemWatcher.Changed += FileSystemWatcher_Changed;
                fileSystemWatcher.Renamed += FileSystemWatcher_Renamed;

                watchers.Add(path, fileSystemWatcher);
            }
        }

        public void Stop(string path)
        {
            onStop.Invoke(path, true);

            watchers.Remove(path);

            FileSystemWatcher fileSystemWatcher = watchers[path];
            fileSystemWatcher.Deleted -= FileSystemWatcher_Deleted;
            fileSystemWatcher.Changed -= FileSystemWatcher_Changed;
            fileSystemWatcher.Renamed -= FileSystemWatcher_Renamed;
            fileSystemWatcher.Dispose();

            // During delete call onStop which call this method
        }

        private void FileSystemWatcher_Renamed(object sender, RenamedEventArgs e)
        {
            onStop.Invoke(e.OldFullPath, true);
            onStart.Invoke(e.FullPath, true);
        }

        private void FileSystemWatcher_Changed(object sender, FileSystemEventArgs e)
        {
            onStop.Invoke(e.FullPath, true);
            onStart.Invoke(e.FullPath, true);
        }

        private void FileSystemWatcher_Deleted(object sender, FileSystemEventArgs e)
        {
            onStop.Invoke(e.FullPath, true);
        }

        public void Stop()
        {

        }
    }
}

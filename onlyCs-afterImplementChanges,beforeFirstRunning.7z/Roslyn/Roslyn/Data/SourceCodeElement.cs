﻿using sunamo.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


public class SourceCodeElement
    {
        public int File = 0;
        public NamespaceCodeElementsType type;
        
    }


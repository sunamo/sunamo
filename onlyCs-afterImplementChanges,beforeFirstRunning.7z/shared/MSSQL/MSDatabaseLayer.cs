﻿using System.IO;


using System.Collections.Generic;
using System;
using System.Text;
using System.Data.SqlClient;
using System.Web;
using sunamo.Values;

public partial class MSDatabaseLayer : MSDatabaseLayerBase
{



    /// <summary>
    /// Není veřejná, místo ní používej pro otevírání databáze metodu LoadNewConnectionFirst
    /// Používá se když chci otevřít nějakou DB která nenese jen jméno aplikace
    /// </summary>
    /// <param name="file"></param>
    private static bool LoadNewConnection(string dataSource, string database)
    {
        string cs = null;
        cs = "Data Source=" + dataSource;
        if (!string.IsNullOrEmpty(database))
        {
            cs += ";Database=" + database;
        }
        cs += ";Integrated Security=True;MultipleActiveResultSets=True;";
        _conn = new SqlConnection(cs);
        try
        {
            _conn.Open();
        }
        catch (Exception)
        {
            return false;
        }
        return true;

    }


    public static SqlConnection conn
    {
        get
        {
            return _conn;
        }
    }



    

    public static void LoadNewConnection(string cs)
    {
        _conn = new SqlConnection(cs);

        if (!string.IsNullOrEmpty(_conn.ConnectionString))
        {
            _conn.Open();
        }
        
    }





}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Data;
using System.Data.SqlClient;
using sunamo;
using sunamo.Values;

public partial class MSStoredProceduresIBase{ 
public void RepairConnection()
    {
        SqlConnection.ClearAllPools();
        conn.Close();
    }

    SqlConnection _conn = null;
    public SqlConnection conn
    {
        get
        {
            if (_conn == null)
            {
                return MSDatabaseLayer.conn;
            }

            return _conn;
        }

        set
        {
            _conn = value;
        }
    }

    public MSStoredProceduresIBase(SqlConnection conn)
    {
        this.conn = conn;
    }
}
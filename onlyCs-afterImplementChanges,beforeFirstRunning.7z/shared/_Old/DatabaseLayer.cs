﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


public class DatabaseLayer
{
    public static void LoadNewConnection()
    {
        // TODO: Inspire with other same name methods SocialNetworkManager
        throw new NotImplementedException();
    }
}


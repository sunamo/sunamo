﻿public enum AccessModifiers
{
    Public,
    Private,
    Internal,
    Protected
}

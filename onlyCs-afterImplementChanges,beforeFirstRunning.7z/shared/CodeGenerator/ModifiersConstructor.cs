﻿public enum ModifiersConstructor
{
    Public,
    Private,
    Static,
    Internal
}

﻿public interface IUri
{
    string Uri { get; set; }
}

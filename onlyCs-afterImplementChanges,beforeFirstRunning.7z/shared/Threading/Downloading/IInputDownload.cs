﻿public interface IInputDownload : IUri //IException,
{

}

﻿using System.Drawing;

/* 
shared/Delegates/CodeFile1.cs
*/

public delegate void VoidColor(System.Drawing.Color c);


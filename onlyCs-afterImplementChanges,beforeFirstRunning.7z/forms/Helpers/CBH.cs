﻿using System.Windows.Forms;
using System.IO;
namespace forms
{
    public class CBH
    {
        

        public static int IndexOf(ComboBox comboBox3, string p)
        {
            int i = 0;
            foreach (string var in comboBox3.Items)
            {
                if (var == p)
                {
                    return i;
                }
                i++;
            }
            return -1;
        }
    }
}

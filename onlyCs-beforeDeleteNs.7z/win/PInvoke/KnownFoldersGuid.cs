﻿using System;
public static class KnownFoldersGuid
{
    public static readonly Guid Downloads = new Guid("374DE290-123F-4565-9164-39C4925E467B");
}

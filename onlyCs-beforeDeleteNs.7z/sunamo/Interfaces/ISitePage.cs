﻿using System;
public interface ISitePage
{
    //string DateTimeToString(DateTime dt);
}

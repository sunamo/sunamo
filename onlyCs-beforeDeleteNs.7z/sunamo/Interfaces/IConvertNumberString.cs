﻿public interface IConvertNumberString
{
    int ToNumber(string s);
    string ToString(int number);

}

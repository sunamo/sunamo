﻿public interface IConvertConvention
{
    string FromConvention(string p);
    string ToConvention(string p);
}

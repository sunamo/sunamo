﻿using System;
public interface IException
{
    Exception Ex { get; set; }
}

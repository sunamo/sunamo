﻿public interface IWorking
{
    bool IsWorking { get; }
}

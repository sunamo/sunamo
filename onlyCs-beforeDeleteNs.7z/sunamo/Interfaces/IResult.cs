﻿/// <summary>
/// Dont use, instead of this IUserControlWithResult
/// </summary>
public interface IResult
{
    //object Result { get; }
    /// <summary>
    /// Dont use, instead of this IUserControlWithResult
    /// </summary>
    event VoidObject Finished;
}

﻿public interface IPath
{
    string Path { get; set; }
}

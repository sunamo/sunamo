﻿public interface IIDParent
{
    int IDParent { get; set; }
}

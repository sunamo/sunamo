﻿public interface ISerialization
{
    void Load(object obj);
    void Save();
}

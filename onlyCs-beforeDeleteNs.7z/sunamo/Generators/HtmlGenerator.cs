﻿using System;
using System.Text;
using System.Collections.Generic;
public  class HtmlGenerator : XmlGenerator
{
    public void WriteBr()
    {
        base.WriteNonPairTag("br");
    }

    public void Boilerplate()
    {
        
    }
}

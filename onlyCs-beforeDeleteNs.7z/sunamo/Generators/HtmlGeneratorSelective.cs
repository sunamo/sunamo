﻿public  class HtmlGeneratorSelective : XmlGeneratorSelective
{

}

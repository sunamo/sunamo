﻿using System;
using System.Collections.Generic;
using System.Text;

namespace sunamo.Values
{
    public class TestDataCs
    {
        public const string a = "a.cs";
        public const string ab = "ab.cs";
        public const string b = "b.cs";
        public const string c = "c.cs";
        public const string a2 = "a2.cs";
    }
}

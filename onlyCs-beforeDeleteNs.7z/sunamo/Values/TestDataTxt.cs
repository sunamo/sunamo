﻿using System;
using System.Collections.Generic;
using System.Text;

namespace sunamo.Values
{
    public class TestDataTxt
    {
        public const string a = "a.txt";
        public const string ab = "ab.txt";
        public const string b = "b.txt";
        public const string c = "c.txt";
        public const string a2 = "a2.txt";
    }
}

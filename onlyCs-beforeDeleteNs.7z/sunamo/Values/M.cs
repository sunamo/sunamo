﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/// <summary>
/// Already don't in use, only for apps which still use it  and are waiting for convert
/// 
/// Apps:
/// </summary>
public partial class M
{
    public static bool Auto = false;
}


﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sunamo
{
    public class GoogleApiCodes
    {
        public const string sunamoYoutubeClientId = "559015172873-rfu7snt8hm028sdl889btrj1l7ttdn19.apps.googleusercontent.com";
        public const string sunamoYoutubeClientSecret = "fmyFtNvsCd1OJK8ojt6Mx_Ff";
    }
}

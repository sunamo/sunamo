﻿using System;
using System.Collections.Generic;
using System.Text;


    public class HtmlAttrValue
    {
        public const string textCss = "text/css";
        public const string stylesheet = "stylesheet";
        public static string server = "server";
    public static string text = "text";
}


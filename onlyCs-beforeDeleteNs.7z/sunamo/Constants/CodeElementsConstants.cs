﻿using System;
using System.Collections.Generic;
using System.Text;

namespace sunamo.Constants
{
    public class CodeElementsConstants
    {
        public const string NopeValue = "Nope";
        public const string NoneValue = "None";
    }
}

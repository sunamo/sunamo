﻿using System;
using System.Collections.Generic;
using System.Text;

namespace sunamo.Constants
{
    public class ControlNames
    {
        public const string tb = "tb";
        public const string txt = "txt";
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace sunamo.Constants
{
    public class ExecutablePaths
    {
        public const string foobar = @"C:\Program Files (x86)\foobar2000\foobar2000.exe";
    }
}

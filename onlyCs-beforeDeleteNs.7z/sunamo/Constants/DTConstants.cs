﻿using System;
using System.Collections.Generic;
using System.Text;


    public partial class DTConstants
    {
    

        

    
        

    }


﻿using System;
using System.Collections.Generic;
using System.Text;

namespace sunamo.Constants
{
    public class CsKeywords
    {
        public static string  c= "class";

    }
}
﻿public class PGPhoto
{
    public string link = "";
    public string tn = "";
    public string name = "";
}

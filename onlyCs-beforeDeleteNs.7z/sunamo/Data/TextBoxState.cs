﻿using System;
using System.Collections.Generic;
using System.Text;

namespace sunamo.Data
{
    public class TextBoxState
    {
        public string textActualFile = "";
        public string textSearchedResult = "";
    }
}

﻿/// <summary>
/// Jakékoliv změny v této složce musíš projevit i v stejně pojmenované třídě v swf projektu
/// </summary>
public class ExternalLoginResult
{
    public int IdUser
    {
        get;
        set;
    }

    public string Sc
    {
        get;
        set;
    }
}

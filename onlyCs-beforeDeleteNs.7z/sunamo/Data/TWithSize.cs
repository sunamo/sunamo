﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sunamo.Data
{
    public class TWithSize<T>
    {
        public T t = default(T);
        public long size = 0;
    }

    
}

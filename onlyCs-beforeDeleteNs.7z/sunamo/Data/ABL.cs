﻿using System;
using System.Collections.Generic;
using System.Text;

namespace sunamo.Data
{
    public  class ABL<T, U>
    {
        public List<T> a;
        public List<T> b;

    }
}

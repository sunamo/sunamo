﻿public class Speed
{
    public double kmph = 0;
    public double mps = 0;
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sunamo.Data
{
    public class CheckBoxData<T>
    {
        public bool? tick = false;
        /// <summary>
        /// Na to co se má zobrazit
        /// </summary>
        public T t = default(T);
    }
}

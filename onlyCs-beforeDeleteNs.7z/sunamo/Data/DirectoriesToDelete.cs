﻿using System.Collections.Generic;
namespace Sunamo.Data
{
    public class DirectoriesToDelete
    {
        public int hloubka = 0;
        public List<Dictionary<string, List<string>>> adresare = new List<Dictionary<string, List<string>>>();
    }
}

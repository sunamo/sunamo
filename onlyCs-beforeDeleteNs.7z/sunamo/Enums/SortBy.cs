﻿public enum SortBy
{
    Popularity,
    Date
}

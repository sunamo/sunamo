﻿public enum ObjectInitializationOptions
{
    Hyphens,
    Original,
    NewAssign
}

﻿public enum DirectoryMoveCollisionOption
{
    AddSerie,
    Overwrite,
    DiscardFrom
}

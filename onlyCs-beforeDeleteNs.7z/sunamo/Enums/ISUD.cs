﻿public enum ISUD
{
    Insert,
    Select,
    Update,
    Delete
}

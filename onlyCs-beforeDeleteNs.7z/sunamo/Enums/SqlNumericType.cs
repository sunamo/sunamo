﻿public enum SqlNumericType
{
    Int,Long,Short,Byte
}

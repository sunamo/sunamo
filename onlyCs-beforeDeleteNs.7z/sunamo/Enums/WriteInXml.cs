﻿/// <summary>
/// 
/// </summary>
public enum WriteInXml
{
    Atributech,
    Prvcich
}

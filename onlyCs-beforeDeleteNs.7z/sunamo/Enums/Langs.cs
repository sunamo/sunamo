﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

    /// <summary>
    /// Pokud používáš toto, musíš zároveň implementovat např. zobrazování a parsování času aj. 
    /// Snaž se to ale nepoužívat, všechny jazykové prostředky vkládej do xlf
    /// </summary>
    public enum Langs : byte
    {
        cs = 0,
        en = 1        
    }


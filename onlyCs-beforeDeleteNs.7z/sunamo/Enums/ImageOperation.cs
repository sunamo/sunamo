﻿public enum ImageOperation
{
    Crop,
    Shrink
}

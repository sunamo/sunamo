﻿public enum AppFolders
{
    Input,
    Output,
    Settings,
    Data,
    Logs,
    Other,
    Controls,
    Cache,
    Local,
    Roaming,
    Temp
}

﻿public enum SourceMailDomain
{
    Live,
    Gmail,
    Seznam
}

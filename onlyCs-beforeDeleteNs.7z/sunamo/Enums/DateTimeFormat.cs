﻿public enum DateTimeFormat
{
    Czech,
    USA
}

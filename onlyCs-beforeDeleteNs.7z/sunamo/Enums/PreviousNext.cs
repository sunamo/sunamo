﻿public enum PreviousNext
{
    Previous,
    Next
}

﻿/// <summary>
/// Případy licence které mohou být
/// </summary>
public enum RunTypes
{
    Trial,
    Full,
    Expired,
    Unknown
}

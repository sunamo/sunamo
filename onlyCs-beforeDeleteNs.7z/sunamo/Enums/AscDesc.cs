﻿public enum AscDesc
{
    Asc,
    Desc
}

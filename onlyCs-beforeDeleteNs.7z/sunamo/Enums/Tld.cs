﻿public enum Tld
{
    cz
}

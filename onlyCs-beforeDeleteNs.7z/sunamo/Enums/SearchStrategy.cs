﻿using System;
using System.Collections.Generic;
using System.Text;


    public enum SearchStrategy
    {
        FixedSpace,
        AnySpaces,
        ExactlyName
    }


﻿public enum CssNamedColors
{
    darkgreen,
    red,
    orange,
    black,
    lightgreen
}

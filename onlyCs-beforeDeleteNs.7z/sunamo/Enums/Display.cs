﻿public enum AllOne
{
    All,
    One
}

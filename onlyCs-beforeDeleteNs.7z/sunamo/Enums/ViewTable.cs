﻿public enum ViewTable : byte
{
    Phs_PhsGallery = 0,
    Phs_PhsAlbum = 1,
    Phs_PhsPhoto = 2,
    App_App = 3,
    Lyr_Song = 4,
    Geo_Caches = 5,
    Geo_UploadedGpxTracks = 6,
    Sda_Video = 7,
    Sda_Activity = 8
}

﻿public enum TypeOfMessage
{
    Error,
    Warning,
    Information,
    Ordinal,
    Appeal,
    Success
}

﻿/// <summary>
/// 
/// </summary>
public enum TypeOfFile
{
    Binary,
    Image,
    Text,
    Unknown
}

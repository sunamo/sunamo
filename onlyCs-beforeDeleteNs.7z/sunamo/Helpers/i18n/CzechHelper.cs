﻿public class CzechHelper
{
    public static string Dear(bool sex)
    {
        if (sex)
        {
            return "Milá";
        }
        return "Milý";
    }
}

﻿public class WaitingManagerAspxPagesID
{
    public const int Geo_Caches = 1;
}

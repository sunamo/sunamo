﻿public class CookieNames
{
    public const string sCzSc = "sCzSc";
    public const string sCzIdUser = "sCzIdUser";
    public const string sCzLogin = "sCzLogin";
}

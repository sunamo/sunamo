﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Roslyn
{
    class Method
    {
        // whether I can scan source code and simply add
        bool IsStatic;
        string ns;
        string type;
        string name;
        string content;
    }
}

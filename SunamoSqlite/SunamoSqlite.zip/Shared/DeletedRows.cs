﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;

namespace DocArch.SqLite
{
    public class DeletedRows
    {
        public int quantity = 0;
        public DataTable deletedRows = null;
        public string chyba = null;
    }
}

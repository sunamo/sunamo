﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;

namespace DocArch.SqLite
{
    public class SelectedRows
    {
        public int quantity = 0;
        public DataTable selectedRows = null;
        public string error = null;
    }
}

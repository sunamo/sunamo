﻿using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Text;


public static class SQLiteConnectionExtensions
{
    public static void ChangePassword(this SQLiteConnection c, string pw)
    {
    }
}

